#ifndef __RESOURCE_libxfce4ui_H__
#define __RESOURCE_libxfce4ui_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *libxfce4ui_get_resource (void);
#endif
