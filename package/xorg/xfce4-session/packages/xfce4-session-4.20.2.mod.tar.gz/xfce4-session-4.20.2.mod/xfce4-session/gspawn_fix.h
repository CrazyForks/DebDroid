#ifndef GSPAWN_FIX_H
#define GSPAWN_FIX_H

#include <glib.h>

#ifdef __cplusplus
extern "C" {
#endif

gboolean new_g_spawn_sync(
    const gchar *working_directory,
    gchar **argv,
    gchar **envp,
    GSpawnFlags flags,
    GSpawnChildSetupFunc child_setup,
    gpointer user_data,
    gchar **standard_output,
    gchar **standard_error,
    gint *exit_status,
    GError **error
);

gboolean new_g_spawn_command_line_sync(
    const gchar *command_line,
    gchar **standard_output,
    gchar **standard_error,
    gint *exit_status,
    GError **error
);

#ifdef __cplusplus
}
#endif

#endif

