#include <spawn.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>
#include <glib.h>
#include <stdio.h>
#include <unistd.h>

extern char **environ;

gboolean new_g_spawn_sync(
    const gchar *working_directory,
    gchar **argv,
    gchar **envp,
    GSpawnFlags flags,
    GSpawnChildSetupFunc child_setup,
    gpointer user_data,
    gchar **standard_output,
    gchar **standard_error,
    gint *exit_status,
    GError **error
) {
    pid_t pid;
    int status;
    int rc;
    char **envp_to_use = envp ? envp : environ;

    if (!argv || !argv[0]) {
        g_set_error(error, G_SPAWN_ERROR, G_SPAWN_ERROR_FAILED,
                    "new_g_spawn_sync: invalid argv");
        return FALSE;
    }

    char *old_cwd = NULL;
    if (working_directory) {
        old_cwd = g_get_current_dir();
        if (chdir(working_directory) != 0) {
            g_set_error(error, G_SPAWN_ERROR, G_SPAWN_ERROR_FAILED,
                        "chdir(%s) failed: %s", working_directory, g_strerror(errno));
            g_free(old_cwd);
            return FALSE;
        }
    }

    rc = posix_spawn(&pid, argv[0], NULL, NULL, argv, envp_to_use);

    if (working_directory && old_cwd) {
        chdir(old_cwd);
        g_free(old_cwd);
    }

    if (rc != 0) {
        g_set_error(error, G_SPAWN_ERROR, G_SPAWN_ERROR_FAILED,
                    "posix_spawn failed: %s", g_strerror(rc));
        return FALSE;
    }

    if (waitpid(pid, &status, 0) == -1) {
        g_set_error(error, G_SPAWN_ERROR, G_SPAWN_ERROR_FAILED,
                    "waitpid failed: %s", g_strerror(errno));
        return FALSE;
    }

    if (exit_status)
        *exit_status = WEXITSTATUS(status);

    if (standard_output)
        *standard_output = g_strdup("");
    if (standard_error)
        *standard_error = g_strdup("");

    return TRUE;
}

gboolean new_g_spawn_command_line_sync(const gchar *command_line,
                                       gchar **standard_output,
                                       gchar **standard_error,
                                       gint *exit_status,
                                       GError **error)
{
    gboolean res;
    gint argc = 0;
    gchar **argv = NULL;
    GError *local_error = NULL;

    res = g_shell_parse_argv(command_line, &argc, &argv, &local_error);
    if (!argv) {
        if (error) *error = local_error;
        return FALSE;
    }

    gboolean result = new_g_spawn_sync(NULL, argv, NULL,
                                       G_SPAWN_SEARCH_PATH,
                                       NULL, NULL,
                                       standard_output,
                                       standard_error,
                                       exit_status,
                                       error);

    g_strfreev(argv);
    return result;
}

