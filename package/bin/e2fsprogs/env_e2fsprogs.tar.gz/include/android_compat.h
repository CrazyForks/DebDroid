#ifndef ANDROID_COMPAT_H
#define ANDROID_COMPAT_H

#include <stdlib.h>
#include <paths.h>  /* for _PATH_MOUNTED */

// librandom

#if defined(__ANDROID__)
ssize_t getrandom(void *buf, size_t buflen, unsigned int flags);
int getentropy(void *buf, size_t buflen);
#endif

// libmnt

#define MOUNTED _PATH_MOUNTED

#define MNTTYPE_IGNORE "ignore"
#define MNTTYPE_NFS "nfs"
#define MNTTYPE_SWAP "swap"

#define MNTOPT_DEFAULTS "defaults"
#define MNTOPT_NOAUTO "noauto"
#define MNTOPT_NOSUID "nosuid"
#define MNTOPT_RO "ro"
#define MNTOPT_RW "rw"
#define MNTOPT_SUID "suid"

#if defined(__ANDROID__)
struct mntent* getmntent(FILE* stream);
FILE* setmntent(const char* file, const char* mode);
struct mntent* hasmntopt(struct mntent* mnt, const char* opt);
int endmntent(FILE* stream);
#endif

// sync_file_range

#ifndef SYNC_FILE_RANGE_WAIT_BEFORE
#define SYNC_FILE_RANGE_WAIT_BEFORE 1
#endif

#ifndef SYNC_FILE_RANGE_WRITE
#define SYNC_FILE_RANGE_WRITE 2
#endif

#ifndef SYNC_FILE_RANGE_WAIT_AFTER
#define SYNC_FILE_RANGE_WAIT_AFTER 4
#endif

#if defined(__ANDROID__)
extern int sync_file_range(int fd, off64_t offset, off64_t nbytes, unsigned int flags);
#endif

#endif /* ANDROID_COMPAT_H */
