#!/bin/bash
# env_android.sh

# NDK & toolchain paths
export NDK_ROOT=$PWD/android-ndk-r27d # Edit me!
export TOOLCHAIN=$NDK_ROOT/toolchains/llvm/prebuilt/linux-x86_64

# Target Architecture
export ARCH=aarch64
export TARGET=aarch64-linux-android

# Compiler paths
export CC=$TOOLCHAIN/bin/${TARGET}21-clang
export AR=$TOOLCHAIN/bin/llvm-ar
export RANLIB=$TOOLCHAIN/bin/llvm-ranlib
export STRIP=$TOOLCHAIN/bin/llvm-strip

# Sysroot path
export SYSROOT=$TOOLCHAIN/sysroot

# Compiler & linker flags
export CFLAGS="-I$SYSROOT/usr/include -Os -fomit-frame-pointer -include $PWD/include/android_compat.h"
export LDFLAGS="-L$SYSROOT/usr/lib/aarch64-linux-android/21 -static -Wl,--gc-sections"
unset CXXFLAGS
