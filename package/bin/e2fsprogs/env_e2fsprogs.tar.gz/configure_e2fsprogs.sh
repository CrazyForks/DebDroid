#!/bin/sh
# configure_e2fsprogs.sh

set -eu

cd android_external_e2fsprogs

./configure \
    --host=$TARGET \
    --disable-fsck \
    --disable-uuidd \
    --disable-nls \
    --disable-backtrace \
    --disable-fuse2fs
